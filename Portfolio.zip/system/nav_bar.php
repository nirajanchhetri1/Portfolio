<ul>
  <li>
    <a href="dashboard.php">dashboard</a>
  </li>
  <li>
    <a href="portfolio.php">Portfolio</a>
  </li>
  <li>
    <a href="blog.php">Blogs</a>
  </li>
  <li>
    <a href="page_description.php">Page Description</a>
  </li>
  <li>
    <a href="contact.php">Contact</a>
  </li>
  <li>
    <a href="experiences.php">Experiences</a>
  </li>
  <li>
    <a href="cvs.php">CV</a>
  </li>
  <li>
    <a href="skills.php">Skills</a>
  </li>
  <li>
    <a href="educations.php">Educations</a>
  </li>
  <li>
    <a href="about.php">About</a>
  </li>
  <li>
    <a href="namelogo.php">Nav Logo</a>
  </li>
</ul>